package com.example.graphql.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import com.example.graphql.entity.ExternalServiceResponse;
import com.example.graphql.security.JwtUtil;
import io.jsonwebtoken.JwtException;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
public class ExternalServiceClientTest {

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private UserService userService;

    @Mock
    private JwtUtil jwtUtil;

    private ExternalServiceClient externalServiceClient;

    private UserDetails userDetails;
    private String validToken;

    @BeforeEach
    void setUp() {
        WebClient.Builder webClientBuilder = mock(WebClient.Builder.class);
        when(webClientBuilder.build()).thenReturn(webClient);

        externalServiceClient = new ExternalServiceClient(jwtUtil, webClientBuilder);

        // Use reflection to set mocked dependencies
        try {
            java.lang.reflect.Field userServiceField = ExternalServiceClient.class.getDeclaredField("userService");
            userServiceField.setAccessible(true);
            userServiceField.set(externalServiceClient, userService);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set up test dependencies", e);
        }

        // Setup common test data
        userDetails = User.withUsername("testuser")
                .password("password")
                .authorities(Collections.emptyList())
                .build();
        validToken = "valid.jwt.token";
    }

    @Test
    void testCallServiceA_Success() {
        // Arrange
        String id = "123";
        ExternalServiceResponse mockResponse = new ExternalServiceResponse("Service A data");

        // Token validation
        when(jwtUtil.extractUsername(validToken)).thenReturn("testuser");
        when(userService.loadUserByUsername("testuser")).thenReturn(userDetails);
        when(jwtUtil.validateToken(validToken, userDetails)).thenReturn(true);

        // WebClient setup
        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ExternalServiceResponse.class)).thenReturn(Mono.just(mockResponse));

        // Act & Assert
        StepVerifier.create(externalServiceClient.callServiceA(id, validToken))
                .expectNext(mockResponse)
                .verifyComplete();

        // Verify interactions
        verify(jwtUtil).extractUsername(validToken);
        verify(userService).loadUserByUsername("testuser");
        verify(jwtUtil).validateToken(validToken, userDetails);
    }

    @Test
    void testCallServiceA_TokenValidationFailed() {
        // Arrange
        String id = "123";

        // Token validation fails
        when(jwtUtil.extractUsername(validToken)).thenReturn("testuser");
        when(userService.loadUserByUsername("testuser")).thenReturn(userDetails);
        when(jwtUtil.validateToken(validToken, userDetails)).thenReturn(false);

        // Act & Assert
        StepVerifier.create(externalServiceClient.callServiceA(id, validToken))
                .expectError(JwtException.class)
                .verify();
    }

    @Test
    void testCallServiceA_ServiceError() {
        // Arrange
        String id = "123";

        // Token validation
        when(jwtUtil.extractUsername(validToken)).thenReturn("testuser");
        when(userService.loadUserByUsername("testuser")).thenReturn(userDetails);
        when(jwtUtil.validateToken(validToken, userDetails)).thenReturn(true);

        // WebClient setup to simulate service error
        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ExternalServiceResponse.class))
                .thenReturn(Mono.error(new WebClientResponseException(500, "Internal Server Error", null, null, null)));

        // Act & Assert
        StepVerifier.create(externalServiceClient.callServiceA(id, validToken))
                .expectNext(new ExternalServiceResponse("Service A unavailable. Try again later."))
                .verifyComplete();
    }

    @Test
    void testCallServiceB_Success() {
        // Arrange
        String id = "456";
        ExternalServiceResponse mockResponse = new ExternalServiceResponse("Service B data");

        // Token validation
        when(jwtUtil.extractUsername(validToken)).thenReturn("testuser");
        when(userService.loadUserByUsername("testuser")).thenReturn(userDetails);
        when(jwtUtil.validateToken(validToken, userDetails)).thenReturn(true);

        // WebClient setup
        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ExternalServiceResponse.class)).thenReturn(Mono.just(mockResponse));

        // Act & Assert
        StepVerifier.create(externalServiceClient.callServiceB(id, validToken))
                .expectNext(mockResponse)
                .verifyComplete();

        // Verify interactions
        verify(jwtUtil).extractUsername(validToken);
        verify(userService).loadUserByUsername("testuser");
        verify(jwtUtil).validateToken(validToken, userDetails);
    }

    @Test
    void testCallExternalService_Success() {
        // Arrange
        when(jwtUtil.extractUsername(validToken)).thenReturn("testuser");
        when(userService.findByUsernameReactive("testuser")).thenReturn(Mono.just(userDetails));
        when(jwtUtil.validateToken(validToken, userDetails)).thenReturn(true);

        // WebClient setup
        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(anyString(), anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(Void.class)).thenReturn(Mono.empty());

        // Act & Assert
        StepVerifier.create(externalServiceClient.callExternalService(validToken))
                .verifyComplete();

        // Verify interactions
        verify(jwtUtil).extractUsername(validToken);
        verify(userService).findByUsernameReactive("testuser");
        verify(jwtUtil).validateToken(validToken, userDetails);
    }

    @Test
    void testCallExternalService_InvalidToken() {
        // Arrange
        String invalidToken = "invalid.token";

        // Act & Assert
        StepVerifier.create(externalServiceClient.callExternalService(invalidToken))
                .expectError(RuntimeException.class)
                .verify();
    }

    @Test
    void testCallExternalService_EmptyToken() {
        // Act & Assert
        StepVerifier.create(externalServiceClient.callExternalService(""))
                .expectError(RuntimeException.class)
                .verify();
    }
}
