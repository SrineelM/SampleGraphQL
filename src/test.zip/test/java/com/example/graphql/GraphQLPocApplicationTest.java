package com.example.graphql;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.graphql.service.PostService;
import com.example.graphql.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.core.env.Environment;

@ExtendWith(MockitoExtension.class)
public class GraphQLPocApplicationTest {

    @Mock
    private UserService userService;

    @Mock
    private PostService postService;

    @Mock
    private Environment environment;

    private GraphQLPocApplication application;

    @BeforeEach
    void setUp() {
        application = new GraphQLPocApplication(userService, postService, environment);
    }

    @Test
    void testMainMethod() {
        // Use MockedStatic to verify SpringApplication.run is called
        try (MockedStatic<SpringApplication> springApplicationMockedStatic = mockStatic(SpringApplication.class)) {
            // Call main method
            GraphQLPocApplication.main(new String[] {});

            // Verify SpringApplication.run was called with correct arguments
            springApplicationMockedStatic.verify(
                    () -> SpringApplication.run(GraphQLPocApplication.class, new String[] {}), times(1));
        }
    }

    @Test
    void testRunMethod_DevProfile() {
        // Arrange
        when(environment.getActiveProfiles()).thenReturn(new String[] {"dev"});

        // Capture logger
        Logger logger = mock(Logger.class);
        try (MockedStatic<LoggerFactory> loggerFactoryMockedStatic = mockStatic(LoggerFactory.class)) {
            loggerFactoryMockedStatic
                    .when(() -> LoggerFactory.getLogger(GraphQLPocApplication.class))
                    .thenReturn(logger);

            // Act
            application.run();

            // Assert
            verify(logger).info("Startup: DEV profile active. Data will be seeded via data.sql.");
        }
    }

    @Test
    void testRunMethod_NonDevProfile() {
        // Arrange
        when(environment.getActiveProfiles()).thenReturn(new String[] {"prod"});

        // Capture logger
        Logger logger = mock(Logger.class);
        try (MockedStatic<LoggerFactory> loggerFactoryMockedStatic = mockStatic(LoggerFactory.class)) {
            loggerFactoryMockedStatic
                    .when(() -> LoggerFactory.getLogger(GraphQLPocApplication.class))
                    .thenReturn(logger);

            // Act
            application.run();

            // Assert
            verify(logger).info("Startup: Skipping data seeding for non-dev profile");
        }
    }

    @Test
    void testConstructor() {
        // Verify constructor sets dependencies correctly
        assertNotNull(application);

        // Use reflection to check private fields if needed
        try {
            // Check UserService
            java.lang.reflect.Field userServiceField = GraphQLPocApplication.class.getDeclaredField("userService");
            userServiceField.setAccessible(true);
            assertSame(userService, userServiceField.get(application));

            // Check PostService
            java.lang.reflect.Field postServiceField = GraphQLPocApplication.class.getDeclaredField("postService");
            postServiceField.setAccessible(true);
            assertSame(postService, postServiceField.get(application));

            // Check Environment
            java.lang.reflect.Field envField = GraphQLPocApplication.class.getDeclaredField("env");
            envField.setAccessible(true);
            assertSame(environment, envField.get(application));
        } catch (Exception e) {
            fail("Failed to verify constructor dependencies: " + e.getMessage());
        }
    }

    @Test
    void testAnnotations() {
        // Verify class-level annotations
        assertTrue(GraphQLPocApplication.class.isAnnotationPresent(
                org.springframework.boot.autoconfigure.SpringBootApplication.class));
        assertTrue(GraphQLPocApplication.class.isAnnotationPresent(
                org.springframework.cache.annotation.EnableCaching.class));
        assertTrue(GraphQLPocApplication.class.isAnnotationPresent(
                org.springframework.transaction.annotation.EnableTransactionManagement.class));
        assertTrue(GraphQLPocApplication.class.isAnnotationPresent(
                org.springframework.boot.autoconfigure.domain.EntityScan.class));
        assertTrue(GraphQLPocApplication.class.isAnnotationPresent(
                org.springframework.data.jpa.repository.config.EnableJpaRepositories.class));
    }
}
