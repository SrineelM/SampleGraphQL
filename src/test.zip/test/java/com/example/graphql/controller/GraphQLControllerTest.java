package com.example.graphql.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.graphql.entity.Post;
import com.example.graphql.entity.User;
import com.example.graphql.service.PostService;
import com.example.graphql.service.UserService;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GraphQLControllerTest {

    @Mock
    private UserService userService;

    @Mock
    private PostService postService;

    @InjectMocks
    private GraphQLController graphQLController;

    private User testUser;
    private Post testPost;

    @BeforeEach
    void setUp() {
        testUser = new User("testuser", "test@example.com", "password", User.Role.ROLE_USER);
        testUser.setId(1L);

        testPost = new Post();
        testPost.setId(1L);
        testPost.setTitle("Test Post");
        testPost.setContent("Test Content");
        testPost.setUser(testUser);
    }

    @Test
    void testGetAllUsers() {
        // Arrange
        List<User> expectedUsers = List.of(testUser);
        when(userService.getAllUsers()).thenReturn(expectedUsers);

        // Act
        List<User> actualUsers = graphQLController.users();

        // Assert
        assertNotNull(actualUsers);
        assertEquals(1, actualUsers.size());
        assertEquals(testUser, actualUsers.get(0));
        verify(userService).getAllUsers();
    }

    @Test
    void testGetAllPosts() {
        // Arrange
        List<Post> expectedPosts = List.of(testPost);
        when(postService.getAllPosts()).thenReturn(expectedPosts);

        // Act
        List<Post> actualPosts = graphQLController.posts();

        // Assert
        assertNotNull(actualPosts);
        assertEquals(1, actualPosts.size());
        assertEquals(testPost, actualPosts.get(0));
        verify(postService).getAllPosts();
    }

    @Test
    void testCreateUser() {
        // Arrange
        String username = "newuser";
        String email = "newuser@example.com";
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setEmail(email);

        when(userService.createUser(newUser)).thenReturn(testUser);

        // Act
        User createdUser = graphQLController.createUser(username, email);

        // Assert
        assertNotNull(createdUser);
        assertEquals(testUser, createdUser);
        verify(userService).createUser(newUser);
    }

    @Test
    void testCreatePost() {
        // Arrange
        String title = "New Post";
        String content = "New Post Content";
        Long authorId = 1L;

        when(userService.findUserById(authorId)).thenReturn(testUser);
        when(postService.createPost(any(Post.class))).thenReturn(testPost);

        // Act
        Post createdPost = graphQLController.createPost(title, content, authorId);

        // Assert
        assertNotNull(createdPost);
        assertEquals(testPost, createdPost);
        verify(userService).findUserById(authorId);
        verify(postService).createPost(any(Post.class));
    }
}
