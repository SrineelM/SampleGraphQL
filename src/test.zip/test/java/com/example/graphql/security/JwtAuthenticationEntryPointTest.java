package com.example.graphql.security;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.example.graphql.api.ApiError;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
public class JwtAuthenticationEntryPointTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ServerWebExchange exchange;

    @Mock
    private AuthenticationException authException;

    private JwtAuthenticationEntryPoint entryPoint;

    @BeforeEach
    void setUp() {
        entryPoint = new JwtAuthenticationEntryPoint(objectMapper);
    }

    @Test
    void testCommence() throws IOException {
        // Arrange
        String path = "/test/path";
        byte[] errorBytes = "{\"message\":\"Unauthorized\"}".getBytes();

        when(exchange.getRequest().getPath().value()).thenReturn(path);
        when(exchange.getResponse().getStatusCode()).thenReturn(null);
        when(exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED)).thenReturn(true);
        when(exchange.getResponse().getHeaders()).thenReturn(mock());
        when(exchange.getResponse().bufferFactory()).thenReturn(mock());
        when(objectMapper.writeValueAsBytes(any(ApiError.class))).thenReturn(errorBytes);
        when(exchange.getResponse().writeWith(any())).thenReturn(Mono.empty());

        // Act & Assert
        StepVerifier.create(entryPoint.commence(exchange, authException)).verifyComplete();

        // Verify interactions
        verify(exchange.getResponse()).setStatusCode(HttpStatus.UNAUTHORIZED);
        verify(exchange.getResponse().getHeaders()).setContentType(MediaType.APPLICATION_JSON);
        verify(objectMapper).writeValueAsBytes(any(ApiError.class));
        verify(exchange.getResponse()).writeWith(any());
    }

    @Test
    void testCommenceWithMapperException() throws IOException {
        // Arrange
        String path = "/test/path";
        when(exchange.getRequest().getPath().value()).thenReturn(path);
        when(exchange.getResponse().getStatusCode()).thenReturn(null);
        when(exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED)).thenReturn(true);
        when(exchange.getResponse().getHeaders()).thenReturn(mock());
        when(objectMapper.writeValueAsBytes(any(ApiError.class))).thenThrow(new IOException("Mapper error"));

        // Act & Assert
        StepVerifier.create(entryPoint.commence(exchange, authException))
                .expectError(IOException.class)
                .verify();
    }

    @Test
    void testApiErrorCreation() throws IOException {
        // Arrange
        String path = "/test/path";
        byte[] errorBytes = "{\"message\":\"Unauthorized\"}".getBytes();

        when(exchange.getRequest().getPath().value()).thenReturn(path);
        when(exchange.getResponse().getStatusCode()).thenReturn(null);
        when(exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED)).thenReturn(true);
        when(exchange.getResponse().getHeaders()).thenReturn(mock());
        when(exchange.getResponse().bufferFactory()).thenReturn(mock());
        when(objectMapper.writeValueAsBytes(any(ApiError.class))).thenReturn(errorBytes);
        when(exchange.getResponse().writeWith(any())).thenReturn(Mono.empty());

        // Act
        Mono<Void> result = entryPoint.commence(exchange, authException);

        // Assert
        StepVerifier.create(result).verifyComplete();

        // Verify ApiError creation
        verify(objectMapper).writeValueAsBytes(argThat(apiError -> {
            assertTrue(apiError instanceof ApiError);
            ApiError error = (ApiError) apiError;
            assertEquals(HttpStatus.UNAUTHORIZED.value(), error.getStatus());
            assertEquals("Unauthorized", error.getMessage());
            assertEquals("Authentication is required to access this resource.", error.getDetails());
            assertEquals(path, error.getPath());
            assertNotNull(error.getTimestamp());
            return true;
        }));
    }
}
